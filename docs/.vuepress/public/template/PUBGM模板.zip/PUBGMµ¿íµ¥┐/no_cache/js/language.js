var GLanguage = {
    "ZH": {
        
    },
    "EN": {
        
    },
    "RU": {
       
    },
    "DE": {
       
    },
    "PT": {
        

    },
    "FR": {
        
    },
    "ES": {
       
    },
    "TR": {
       
    },
    "AR": {
       
    },
}
var language = "EN"

function isEmpty(val) {
    return val == null || val == "" || val == undefined
}
var langObj = null
var areaLan = ["ZH", "EN", "RU", "DE", "PT", "FR", "ES", "TR", "AR"]
var queryString = $.trim(getQueryString("language"))
if (!isEmpty(queryString)) {
    queryString = queryString.toUpperCase()
}
if (areaLan.indexOf(queryString) < 0) {
    language = "EN"
} else {
    language = queryString
}

if (language == "EN") {
    $("body").addClass("lang-en")
} else {
    $("body").removeClass("lang-en")
}
if (language == "RU") {
    $("body").addClass("lang-ru")
} else {
    $("body").removeClass("lang-ru")
}
if (language == "DE") {
    $("body").addClass("lang-de")
} else {
    $("body").removeClass("lang-de")
}
if (language == "HK") {
    $("body").addClass("lang-hk")
} else {
    $("body").removeClass("lang-hk")
}
if (language == "TW") {
    $("body").addClass("lang-tw")
} else {
    $("body").removeClass("lang-tw")
}
if (language == "TH") {
    $("body").addClass("lang-th")
} else {
    $("body").removeClass("lang-th")
}
if (language == "VI") {
    $("body").addClass("lang-vi")
} else {
    $("body").removeClass("lang-vi")
}
if (language == "ID") {
    $("body").addClass("lang-id")
} else {
    $("body").removeClass("lang-id")
}
if (language == "PT") {
    $("body").addClass("lang-pt")
} else {
    $("body").removeClass("lang-pt")
}
if (language == "FR") {
    $("body").addClass("lang-fr")
} else {
    $("body").removeClass("lang-fr")
}
if (language == "ES") {
    $("body").addClass("lang-es")
} else {
    $("body").removeClass("lang-es")
}
if (language == "TR") {
    $("body").addClass("lang-tr")
} else {
    $("body").removeClass("lang-tr")
}
if (language == "AR") {
    $("body").addClass("lang-ar")
} else {
    $("body").removeClass("lang-ar")
}
if (language == "MS") {
    $("body").addClass("lang-my")
} else {
    $("body").removeClass("lang-my")
}

langObj = GLanguage[language]
// document.title = GLanguage[language]["title"]
initLang(langObj)

function initLang(obj) {

    $("[data-lang]").each(function(index) {
        var texts = $(this).attr("data-lang")
        $(this).html(obj[texts])

    })
}
console.log(window.location);

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i")
    var reg_rewrite = new RegExp("(^|/)" + name + "/([^/]*)(/|$)", "i")
    var r = window.location.search.substr(1).match(reg)
    var q = window.location.pathname.substr(1).match(reg_rewrite)
    console.log(q);
    if (r != null) {
        return unescape(r[2])
    } else if (q != null) {
        return unescape(q[2])
    } else {
        return ""
    }
}
if (/iPad/ig.test(navigator.userAgent)) {
    $('.wrap').addClass('ipad');
};